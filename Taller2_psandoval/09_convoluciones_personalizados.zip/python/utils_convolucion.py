
"""
Utilidades para convoluciones manuales y comparación con OpenCV.
"""
import numpy as np
import cv2
from typing import Tuple

def pad_imagen(img: np.ndarray, kernel_shape: Tuple[int, int]) -> np.ndarray:
    kh, kw = kernel_shape
    ph, pw = kh // 2, kw // 2
    return np.pad(img, ((ph, ph), (pw, pw)), mode="reflect")

def conv2d_manual_gray(img_gray: np.ndarray, kernel: np.ndarray) -> np.ndarray:
    """
    Convolución 2D manual sobre imagen en escala de grises (uint8).
    Devuelve uint8.
    """
    assert img_gray.ndim == 2, "La imagen debe ser en escala de grises"
    k = kernel.astype(np.float32)
    k = np.flipud(np.fliplr(k))  # ajustar a la conv clásica
    padded = pad_imagen(img_gray.astype(np.float32), k.shape)
    out = np.zeros_like(img_gray, dtype=np.float32)
    kh, kw = k.shape
    for y in range(out.shape[0]):
        for x in range(out.shape[1]):
            roi = padded[y:y+kh, x:x+kw]
            out[y, x] = np.sum(roi * k)
    out = np.clip(out, 0, 255).astype(np.uint8)
    return out

def conv2d_cv_gray(img_gray: np.ndarray, kernel: np.ndarray) -> np.ndarray:
    k = kernel.astype(np.float32)
    return cv2.filter2D(img_gray, ddepth=-1, kernel=k)

def kernels_basicos():
    sharpen = np.array([[0, -1, 0],
                        [-1, 5, -1],
                        [0, -1, 0]], dtype=np.float32)
    blur = np.ones((3, 3), dtype=np.float32) / 9.0
    # Detector de esquinas/bordes (tipo Laplaciano)
    edges = np.array([[1, -2, 1],
                      [-2, 4, -2],
                      [1, -2, 1]], dtype=np.float32)
    return {"sharpen": sharpen, "blur": blur, "edges": edges}

def combinar_lado_a_lado(imgs, gap=8):
    """
    Une imágenes por columnas (todas uint8, mismas dimensiones y 1 canal).
    """
    imgs = [i if i.ndim==2 else cv2.cvtColor(i, cv2.COLOR_BGR2GRAY) for i in imgs]
    h, w = imgs[0].shape
    canvas = 255*np.ones((h, w*len(imgs) + gap*(len(imgs)-1)), dtype=np.uint8)
    for i, im in enumerate(imgs):
        x = i*(w+gap)
        canvas[:, x:x+w] = im
    return canvas
