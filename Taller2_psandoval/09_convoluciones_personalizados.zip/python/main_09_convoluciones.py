
"""
Ejercicio 09 — Filtro Visual (Convoluciones Personalizadas)
- Convolución 2D manual (grises) y comparación con cv2.filter2D
- Al menos 3 kernels: sharpen, blur, edges/esquinas
- Bonus: sliders para editar pesos del kernel 3x3 en tiempo real
Evidencias: panel comparativo + comentarios en consola
"""
import cv2, numpy as np, argparse
from pathlib import Path
from utils_common import cargar_imagen, mostrar_y_guardar
from utils_convolucion import conv2d_manual_gray, conv2d_cv_gray, kernels_basicos, combinar_lado_a_lado

# Detecta la raíz del repo (buscando 'assets')
ROOT = Path(__file__).resolve()
for _ in range(6):
    if (ROOT / "assets").is_dir():
        break
    ROOT = ROOT.parent
ASSETS = ROOT / "assets"
SALIDAS = ROOT / "gifs"

def preparar_gray(img_bgr):
    return cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)

def comparativa_basica(img_gray):
    ks = kernels_basicos()
    resultados = []
    for nombre, k in ks.items():
        man = conv2d_manual_gray(img_gray, k)
        cv = conv2d_cv_gray(img_gray, k)
        panel = combinar_lado_a_lado([img_gray, man, cv])
        cv2.putText(panel, f"{nombre.upper()} | orig | manual | cv2", (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,), 1)
        resultados.append((nombre, panel))
    return resultados

# BONUS: sliders para modificar kernel 3x3
def interfaz_kernel_dinamico(img_gray):
    win = "09_kernel_dinamico"
    cv2.namedWindow(win)
    # Trackbars: rango -10..10, offset 10
    def mkbar(name):
        cv2.createTrackbar(name, win, 10, 20, lambda v: None)
    names = ["k11","k12","k13","k21","k22","k23","k31","k32","k33"]
    for n in names: mkbar(n)
    cv2.createTrackbar("normalizar(0/1)", win, 1, 1, lambda v: None)

    while True:
        vals = [cv2.getTrackbarPos(n, win)-10 for n in names]
        k = np.array(vals, dtype=np.float32).reshape(3,3)
        if cv2.getTrackbarPos("normalizar(0/1)", win):
            s = k.sum()
            if abs(s) > 1e-6: k = k / s
        man = conv2d_manual_gray(img_gray, k)
        cv = conv2d_cv_gray(img_gray, k)
        panel = np.hstack([img_gray, man, cv])
        cv2.imshow(win, panel)
        key = cv2.waitKey(20) & 0xFF
        if key in (27, ord('q')):
            out_path = SALIDAS / "09_kernel_dinamico_panel.png"
            cv2.imwrite(str(out_path), panel)
            print(f"[INFO] Guardado: {out_path}")
            break
    cv2.destroyWindow(win)

def main():
    parser = argparse.ArgumentParser(description="Ejercicio 09 — Convoluciones")
    parser.add_argument("--img", type=str, default=str(ASSETS / "sample_sintetico.png"),
                        help="Ruta a la imagen de entrada")
    args = parser.parse_args()

    # 1) Cargar imagen
    img = cargar_imagen(args.img)
    gray = preparar_gray(img)

    # 2) Comparativa básica (3 kernels)
    resultados = comparativa_basica(gray)
    for nombre, panel in resultados:
        out_path = SALIDAS / f"09_{nombre}_comparativa.png"
        mostrar_y_guardar(f"09_{nombre}", panel, out_path)

    print("[COMENTARIOS]")
    print("- Sharpen: realza detalles y bordes; puede amplificar ruido.")
    print("- Blur: suaviza y reduce ruido, pero pierde detalle fino.")
    print("- Edges/Esquinas: resalta cambios bruscos; útil para detección de características.")

    # 3) BONUS: interfaz con sliders
    print("[BONUS] Abriendo interfaz de kernel 3x3 (presiona 'q' o ESC para cerrar).")
    interfaz_kernel_dinamico(gray)

if __name__ == "__main__":
    main()
