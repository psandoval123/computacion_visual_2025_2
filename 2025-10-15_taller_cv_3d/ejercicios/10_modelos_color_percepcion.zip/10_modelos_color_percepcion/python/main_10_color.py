
"""
Ejercicio 10 — Explorando el Color (RGB, HSV, CIE Lab + Simulaciones)
- Conversiones RGB↔HSV/Lab (vía BGR de OpenCV)
- Visualización de canales por modelo
- Simulación de daltonismo (protanopía/deuteranopía) con matrices aproximadas
- Baja iluminación (gamma), temperatura, inversión, monocromo
- Bonus: alternar modelos por teclado
Evidencias: comparativas guardadas como PNG
"""
import cv2, numpy as np, argparse
from pathlib import Path
from utils_common import cargar_imagen, mostrar_y_guardar
from utils_color import (bgr_to_models, split_channels, simulate_color_vision_deficiency,
                         apply_low_light, apply_temperature, apply_invert, apply_monochrome)

# Detecta la raíz del repo (buscando 'assets')
ROOT = Path(__file__).resolve()
for _ in range(6):
    if (ROOT / "assets").is_dir():
        break
    ROOT = ROOT.parent
ASSETS = ROOT / "assets"
SALIDAS = ROOT / "gifs"

def panel_canales(titulo, ch1, ch2, ch3, etiquetas):
    h, w = ch1.shape
    panel = np.zeros((h, w*3, 3), dtype=np.uint8)
    panel[:, 0:w,  :] = cv2.cvtColor(ch1, cv2.COLOR_GRAY2BGR)
    panel[:, w:2*w,:] = cv2.cvtColor(ch2, cv2.COLOR_GRAY2BGR)
    panel[:, 2*w:,:] = cv2.cvtColor(ch3, cv2.COLOR_GRAY2BGR)
    cv2.putText(panel, f"{titulo} | {etiquetas[0]} | {etiquetas[1]} | {etiquetas[2]}",
                (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
    return panel

def comparativas_color(img_bgr):
    rgb, hsv, lab = bgr_to_models(img_bgr)
    rgb_ch = split_channels(rgb, "RGB")
    hsv_ch = split_channels(hsv, "HSV")
    lab_ch = split_channels(lab, "LAB")

    pan_rgb = panel_canales("RGB", rgb_ch[0], rgb_ch[1], rgb_ch[2], ["R","G","B"])
    pan_hsv = panel_canales("HSV (H esc 0-255)", hsv_ch[0], hsv_ch[1], hsv_ch[2], ["H","S","V"])
    pan_lab = panel_canales("Lab", lab_ch[0], lab_ch[1], lab_ch[2], ["L","a","b"])
    return pan_rgb, pan_hsv, pan_lab

def simulaciones(img_bgr):
    prot = simulate_color_vision_deficiency(img_bgr, "protanopia")
    deut = simulate_color_vision_deficiency(img_bgr, "deuteranopía"[:-1] + "a")  # ensure 'deuteranopia' spelling
    low = apply_low_light(img_bgr, gamma=1.8)
    warm = apply_temperature(img_bgr, kelvin_shift=1000)
    cool = apply_temperature(img_bgr, kelvin_shift=-1000)
    inv = apply_invert(img_bgr)
    mono = apply_monochrome(img_bgr)

    fila1 = np.hstack([img_bgr, prot, deut])
    fila2 = np.hstack([low, warm, cool])
    fila3 = np.hstack([inv, mono, img_bgr])
    alto = max(fila1.shape[0], fila2.shape[0], fila3.shape[0])
    ancho = max(fila1.shape[1], fila2.shape[1], fila3.shape[1])
    canvas = np.zeros((alto*3, ancho, 3), dtype=np.uint8)
    canvas[0:fila1.shape[0], 0:fila1.shape[1]] = fila1
    canvas[alto:alto+fila2.shape[0], 0:fila2.shape[1]] = fila2
    canvas[2*alto:2*alto+fila3.shape[0], 0:fila3.shape[1]] = fila3

    return canvas

def main():
    parser = argparse.ArgumentParser(description="Ejercicio 10 — Modelos de color y simulaciones")
    parser.add_argument("--img", type=str, default=str(ASSETS / "sample_sintetico.png"),
                        help="Ruta a la imagen de entrada")
    args = parser.parse_args()

    img = cargar_imagen(args.img)

    pan_rgb, pan_hsv, pan_lab = comparativas_color(img)
    mostrar_y_guardar("10_RGB", pan_rgb, SALIDAS / "10_rgb_canales.png")
    mostrar_y_guardar("10_HSV", pan_hsv, SALIDAS / "10_hsv_canales.png")
    mostrar_y_guardar("10_Lab", pan_lab, SALIDAS / "10_lab_canales.png")

    sims = simulaciones(img)
    mostrar_y_guardar("10_Simulaciones", sims, SALIDAS / "10_simulaciones.png")

    print("[REFLEXION BREVE]")
    print("- RGB es aditivo y directo para pantallas; HSV separa tono e intensidad, útil para selección de color.")
    print("- Lab aproxima percepción humana (L=luminosidad), útil para igualación de color.")
    print("- Las simulaciones muestran pérdida de discriminación en rojos (protanopía) o verdes (deuteranopía).")
    print("- La baja iluminación (gamma) reduce visibilidad en sombras; la temperatura desplaza el balance de color.")

    # BONUS: alternar modelos con teclas
    win = "10_bonus_toggle"
    imgs = [img, pan_rgb, pan_hsv, pan_lab, sims]
    idx = 0
    cv2.namedWindow(win)
    while True:
        cv2.imshow(win, imgs[idx])
        key = cv2.waitKey(0) & 0xFF
        if key in (27, ord('q')): break
        if key in (ord('n'), ord(' ')): idx = (idx+1) % len(imgs)
    cv2.destroyWindow(win)

if __name__ == "__main__":
    main()
