
"""
Utilidades para conversiones de color y simulaciones de percepción.
"""
import cv2
import numpy as np

def bgr_to_models(img_bgr):
    img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
    img_hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
    img_lab = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2LAB)
    return img_rgb, img_hsv, img_lab

def split_channels(img, code: str):
    """
    Devuelve lista de 3 canales en uint8 listos para visualizar (escala completa).
    code: 'RGB'|'HSV'|'LAB' (solo informativo).
    """
    ch = cv2.split(img)
    vis = []
    if code == "HSV":
        # V ya está en 0-255; H en OpenCV va 0..179, escalamos a 0..255 para visualizar mejor
        h = (ch[0].astype(np.float32) * (255.0/179.0)).clip(0,255).astype(np.uint8)
        s = ch[1]
        v = ch[2]
        vis = [h, s, v]
    elif code == "LAB":
        # L 0..255; a,b 0..255 pero centro 128; para visualización dejamos tal cual
        vis = [ch[0], ch[1], ch[2]]
    else:
        vis = [ch[0], ch[1], ch[2]]
    return vis

# Simulación simple de daltonismo mediante matrices aproximadas en espacio RGB lineal.
# Nota: Para mayor fidelidad, se recomienda modelos como Brettel o Machado.
PROTANOPIA = np.array([[0.56667, 0.43333, 0.0    ],
                       [0.55833, 0.44167, 0.0    ],
                       [0.0    , 0.24167, 0.75833]], dtype=np.float32)
DEUTERANOPIA = np.array([[0.625  , 0.375  , 0.0    ],
                         [0.7    , 0.3    , 0.0    ],
                         [0.0    , 0.3    , 0.7    ]], dtype=np.float32)

def _to_linear(rgb_u8):
    rgb = rgb_u8.astype(np.float32) / 255.0
    # sRGB -> linear approx
    thr = 0.04045
    lin = np.where(rgb <= thr, rgb/12.92, ((rgb+0.055)/1.055)**2.4)
    return lin

def _to_srgb(lin):
    thr = 0.0031308
    srgb = np.where(lin <= thr, lin*12.92, 1.055*(lin**(1/2.4)) - 0.055)
    srgb = (srgb*255.0).clip(0,255).astype(np.uint8)
    return srgb

def simulate_color_vision_deficiency(img_bgr, kind="protanopia"):
    rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
    lin = _to_linear(rgb)
    M = PROTANOPIA if kind=="protanopia" else DEUTERANOPIA
    # apply per-pixel matrix
    out = lin @ M.T
    out = _to_srgb(out)
    return cv2.cvtColor(out, cv2.COLOR_RGB2BGR)

def apply_low_light(img_bgr, gamma=1.8):
    # gamma > 1 oscurece; simulamos baja iluminación
    inv = 1.0/gamma
    table = ((np.arange(256)/255.0) ** gamma * 255.0).clip(0,255).astype('uint8')
    return cv2.LUT(img_bgr, table)

def apply_temperature(img_bgr, kelvin_shift=1000):
    """
    Ajuste simple de temperatura: +kelvin_shift => más cálido (más R), - => más frío (más B)
    """
    b, g, r = cv2.split(img_bgr)
    factor = np.clip(kelvin_shift/1000.0, -2.0, 2.0)
    if factor >= 0:
        r = cv2.convertScaleAbs(r, alpha=1+0.2*factor, beta=0)
        b = cv2.convertScaleAbs(b, alpha=1-0.2*factor, beta=0)
    else:
        f = -factor
        b = cv2.convertScaleAbs(b, alpha=1+0.2*f, beta=0)
        r = cv2.convertScaleAbs(r, alpha=1-0.2*f, beta=0)
    return cv2.merge([b,g,r])

def apply_invert(img_bgr):
    return 255 - img_bgr

def apply_monochrome(img_bgr):
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    return cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
