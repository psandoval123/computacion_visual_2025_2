
import cv2
import numpy as np
from pathlib import Path

def _raiz_repo(desde: Path) -> Path:
    """
    Intenta ubicar la raíz del repo buscando una carpeta 'assets' al subir niveles.
    """
    p = desde
    for _ in range(5):  # sube hasta 5 niveles por seguridad
        if (p / "assets").is_dir():
            return p
        p = p.parent
    # fallback: 3 niveles arriba desde la carpeta 'python'
    return desde.parents[3]

def cargar_imagen(ruta: str) -> "np.ndarray":
    """
    Carga una imagen desde 'ruta'. Si no existe, usa assets/sample_sintetico.png.
    Devuelve imagen en BGR (uint8).
    """
    p = Path(ruta)
    if p.is_file():
        img = cv2.imread(str(p), cv2.IMREAD_COLOR)
        if img is not None:
            return img

    raiz = _raiz_repo(Path(__file__).resolve())
    fallback = raiz / "assets" / "sample_sintetico.png"
    img = cv2.imread(str(fallback), cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(
            f"No se pudo cargar la imagen ni el fallback.\n"
            f"Intentado: {p}\nFallback: {fallback}"
        )
    return img

def mostrar_y_guardar(nombre_ventana: str, img, salida_path: Path):
    salida_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        import cv2  # ensure available even if headless
        cv2.imshow(nombre_ventana, img)
        cv2.waitKey(1)
    except Exception:
        pass
    import cv2
    cv2.imwrite(str(salida_path), img)
