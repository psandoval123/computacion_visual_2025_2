
# Ejercicio 4 — Imagen = Matriz (Canales, Slicing, Histogramas)

## Objetivo
Manipular píxeles y regiones directamente con OpenCV y NumPy: separación de canales RGB/HSV, edición por slicing (pintar, copiar/pegar regiones), generación de histogramas de intensidad, ajuste de brillo y contraste (manual y con OpenCV CLAHE), y sliders interactivos (para ejecuciones locales).

## Estructura
- data/objetos.jpg  -> coloca aquí tu imagen de entrada
- output/            -> resultados generados (canales, slicing, histogramas, etc.)
- ejercicio4_matriz.py -> script principal (no-interactivo) que genera salidas en /output
- ejercicio4_interactivo.py -> versión con sliders usando cv2 (solo local)
- README.md -> este archivo

## Ejecución
1. Coloca una imagen en `data/objetos.jpg` (idealmente 800x600 o similar).
2. Ejecuta (en Colab o local):
   ```bash
   python ejercicio4_matriz.py
   ```
3. Si trabajas local y quieres sliders interactivos (cv2 windows), ejecuta:
   ```bash
   python ejercicio4_interactivo.py
   ```

## Entregables esperados
- output/channels.png          -> imagen original y canales R,G,B
- output/hsv_channels.png      -> imagen original y canales H,S,V
- output/sliced.png            -> resultado de slicing (pintar, copiar/pegar, atenuar)
- output/hist_gray.png         -> histograma de la imagen en gris
- output/hist_rgb.png          -> histograma por canales RGB
- output/brighter.png          -> ajuste manual brillo/contraste
- output/clahe.png             -> resultado de CLAHE (contraste local)
- output/README_ej4.txt        -> explicación rápida de parámetros usados

## Notas
- Los scripts usan OpenCV (BGR) internamente; para guardar visualizaciones con matplotlib se convierten a RGB.
- Los sliders requieren un entorno con soporte de ventanas (no funcionan en Colab sin workarounds).
