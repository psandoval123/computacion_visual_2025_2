
import cv2
import numpy as np
from pathlib import Path

BASE = Path(__file__).parent
DATA = BASE / "data" / "objetos.jpg"

def nothing(x): pass

img = cv2.imread(str(DATA))
if img is None:
    raise FileNotFoundError("Coloca tu imagen en data/objetos.jpg")

img = cv2.resize(img, (800, int(img.shape[0] * 800 / img.shape[1])))

cv2.namedWindow('BrilloContraste')
cv2.createTrackbar('alpha', 'BrilloContraste', 100, 300, nothing) # alpha*0.01
cv2.createTrackbar('beta', 'BrilloContraste', 50, 100, nothing) # beta-50

while True:
    a = cv2.getTrackbarPos('alpha', 'BrilloContraste') / 100.0
    b = cv2.getTrackbarPos('beta', 'BrilloContraste') - 50
    out = cv2.convertScaleAbs(img, alpha=a, beta=b)
    cv2.imshow('BrilloContraste', out)
    k = cv2.waitKey(30) & 0xFF
    if k == 27:
        break
cv2.destroyAllWindows()
