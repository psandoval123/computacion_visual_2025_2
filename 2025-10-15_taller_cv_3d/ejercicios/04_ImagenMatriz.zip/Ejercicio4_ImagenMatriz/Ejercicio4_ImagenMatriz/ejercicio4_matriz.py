
import cv2
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

BASE = Path(__file__).parent
DATA = BASE / "data" / "objetos.jpg"
OUT = BASE / "output"
OUT.mkdir(parents=True, exist_ok=True)

def load_and_resize(path, width=800):
    img = cv2.imread(str(path))
    if img is None:
        raise FileNotFoundError(f"No se encontró {path}. Coloca tu imagen en data/objetos.jpg")
    h,w = img.shape[:2]
    if w != width:
        scale = width / w
        img = cv2.resize(img, (int(w*scale), int(h*scale)), interpolation=cv2.INTER_AREA)
    return img

def show_and_save_channels(img):
    b,g,r = cv2.split(img)
    fig, axs = plt.subplots(1,4, figsize=(16,5))
    axs[0].imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)); axs[0].set_title("RGB"); axs[0].axis("off")
    axs[1].imshow(r, cmap='gray'); axs[1].set_title("R"); axs[1].axis("off")
    axs[2].imshow(g, cmap='gray'); axs[2].set_title("G"); axs[2].axis("off")
    axs[3].imshow(b, cmap='gray'); axs[3].set_title("B"); axs[3].axis("off")
    plt.tight_layout()
    plt.savefig(OUT / "channels.png", bbox_inches='tight', dpi=150)
    plt.close()

def show_and_save_hsv(img):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    h,s,v = cv2.split(hsv)
    fig, axs = plt.subplots(1,4, figsize=(16,5))
    axs[0].imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)); axs[0].set_title("RGB"); axs[0].axis("off")
    axs[1].imshow(h, cmap='gray'); axs[1].set_title("H"); axs[1].axis("off")
    axs[2].imshow(s, cmap='gray'); axs[2].set_title("S"); axs[2].axis("off")
    axs[3].imshow(v, cmap='gray'); axs[3].set_title("V"); axs[3].axis("off")
    plt.tight_layout()
    plt.savefig(OUT / "hsv_channels.png", bbox_inches='tight', dpi=150)
    plt.close()
    return hsv

def slicing_demo(img):
    out = img.copy()
    h,w = out.shape[:2]
    # pintar un rectángulo rojo (BGR)
    out[10:110, 10:210] = (0,0,255)
    # copiar-pegar región central a la esquina derecha
    y1,y2,x1,x2 = 150,350,200,400
    roi = out[y1:y2, x1:x2].copy()
    out[50:50+(y2-y1), w- (x2-x1) - 50 : w-50] = roi
    # atenuar una región (multiplicar por 0.5)
    out[300:450, 10:160] = (out[300:450, 10:160] * 0.5).astype(np.uint8)
    cv2.imwrite(str(OUT / "sliced.png"), out)
    return out

def histogram_gray(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    hist = cv2.calcHist([gray], [0], None, [256], [0,256])
    plt.figure(figsize=(8,3))
    plt.plot(hist)
    plt.title("Histograma - Gris")
    plt.xlabel("Intensidad"); plt.ylabel("Frecuencia")
    plt.tight_layout()
    plt.savefig(OUT / "hist_gray.png", dpi=150)
    plt.close()
    return hist

def histogram_rgb(img):
    chans = cv2.split(img)
    colors = ('b','g','r')
    plt.figure(figsize=(8,3))
    for chan,col in zip(chans, colors):
        hist = cv2.calcHist([chan], [0], None, [256], [0,256])
        plt.plot(hist, label=col)
    plt.legend()
    plt.title("Histograma - RGB")
    plt.tight_layout()
    plt.savefig(OUT / "hist_rgb.png", dpi=150)
    plt.close()

def adjust_brightness_contrast_manual(img, alpha=1.2, beta=30):
    out = cv2.convertScaleAbs(img, alpha=alpha, beta=beta)
    cv2.imwrite(str(OUT / "brighter.png"), out)
    return out

def adjust_clahe(img, clip_limit=2.0, tile_grid=(8,8)):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    h,s,v = cv2.split(hsv)
    clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=tile_grid)
    v2 = clahe.apply(v)
    hsv2 = cv2.merge([h,s,v2])
    out = cv2.cvtColor(hsv2, cv2.COLOR_HSV2BGR)
    cv2.imwrite(str(OUT / "clahe.png"), out)
    return out

def save_readme_params():
    txt = \"\"\"Parametros usados en ejecucion:
- resize width=800
- slicing: rect (10:110,10:210) pintado rojo
- roi copy region (y1=150,y2=350,x1=200,x2=400)
- histogram bins=256
- ajuste manual: alpha=1.2, beta=30
- CLAHE: clip_limit=2.0, tile_grid=(8,8)
\"\"\"
    with open(OUT / "README_ej4.txt","w") as f:
        f.write(txt)

def main():
    img = load_and_resize(DATA)
    show_and_save_channels(img)
    hsv = show_and_save_hsv(img)
    sliced = slicing_demo(img)
    histogram_gray(img)
    histogram_rgb(img)
    brighter = adjust_brightness_contrast_manual(img, alpha=1.2, beta=30)
    clahe = adjust_clahe(img, clip_limit=2.0, tile_grid=(8,8))
    save_readme_params()
    print("Resultados guardados en output/.")

if __name__ == '__main__':
    main()
