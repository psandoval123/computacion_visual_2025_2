# 🧪 Jerarquías y Transformaciones: El Árbol del Movimiento

## 🧩 Ejercicio Realizado

**Breve explicación (qué hice y por qué):**  
En este ejercicio implementé una escena 3D interactiva usando **React Three Fiber** y **Vite**, enfocándome en comprender cómo funcionan las **transformaciones jerárquicas** en un entorno tridimensional.  

Construí una estructura con tres niveles (padre, hijo y nieto) para observar cómo las transformaciones —traslación, rotación y escala— se propagan en cascada a los objetos hijos.  
El objetivo fue visualizar de forma práctica cómo un cambio en el objeto padre afecta automáticamente a toda la jerarquía, lo que representa un principio clave en los sistemas de gráficos 3D.

También incorporé **controles interactivos con Leva** para manipular el nodo padre en tiempo real (posición, rotación y escala), permitiendo experimentar directamente con las transformaciones y su efecto en los objetos anidados.  

Finalmente, añadí **ayudas visuales** como ejes y grillas para facilitar la comprensión espacial y la relación entre los diferentes niveles de la jerarquía.
