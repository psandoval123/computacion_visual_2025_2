# 👁️ Visión Artificial con OpenCV

## 🧩 Ejercicio Realizado

**Breve explicación (qué hice y por qué):**  
En este ejercicio exploré los fundamentos de la **visión artificial** utilizando la biblioteca **OpenCV en Python**. El objetivo fue entender cómo los computadores pueden procesar imágenes digitales mediante operaciones matemáticas básicas aplicadas sobre los píxeles.

Apliqué **filtros convolucionales** (como desenfoque, enfoque y detección de bordes) para observar cómo modifican las características visuales de una imagen. Utilicé operadores como **Sobel**, **Laplaciano** y **Canny** para comparar sus resultados y comprender cómo cada uno detecta los contornos desde distintos enfoques.

El ejercicio me permitió visualizar de manera práctica la relación entre las **operaciones matemáticas y los efectos visuales**, entendiendo cómo estas transformaciones sirven como base para tareas más avanzadas como la segmentación y el reconocimiento de objetos. Elegí este ejercicio porque proporciona una base sólida para comprender el procesamiento de imágenes antes de pasar a técnicas más complejas basadas en redes neuronales.
