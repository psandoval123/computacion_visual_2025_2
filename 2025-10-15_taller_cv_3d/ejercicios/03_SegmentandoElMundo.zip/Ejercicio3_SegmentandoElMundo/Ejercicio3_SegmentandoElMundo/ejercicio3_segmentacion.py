import cv2
import numpy as np
import imageio

# ------------------------------------------------------------
# 1. Cargar imagen de entrada
# ------------------------------------------------------------
imagen = cv2.imread('data/objetos.jpg')

if imagen is None:
    raise FileNotFoundError("❌ No se encontró la imagen. Verifica la ruta en /data")

imagen = cv2.resize(imagen, (600, 400))
gris = cv2.cvtColor(imagen, cv2.COLOR_BGR2GRAY)

# ------------------------------------------------------------
# 2. Binarización
# ------------------------------------------------------------
_, binaria = cv2.threshold(gris, 127, 255, cv2.THRESH_BINARY)
adaptativa = cv2.adaptiveThreshold(
    gris, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
    cv2.THRESH_BINARY, 11, 3
)

cv2.imwrite('output/binarizada.png', binaria)
cv2.imwrite('output/adaptativa.png', adaptativa)

# ------------------------------------------------------------
# 3. Detección de contornos
# ------------------------------------------------------------
contornos, jerarquia = cv2.findContours(adaptativa, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
resultado = imagen.copy()

for i, contorno in enumerate(contornos):
    area = cv2.contourArea(contorno)
    perimetro = cv2.arcLength(contorno, True)

    if area < 100:
        continue

    M = cv2.moments(contorno)
    if M['m00'] != 0:
        cx = int(M['m10']/M['m00'])
        cy = int(M['m01']/M['m00'])
    else:
        cx, cy = 0, 0

    aprox = cv2.approxPolyDP(contorno, 0.02 * perimetro, True)
    vertices = len(aprox)

    cv2.drawContours(resultado, [contorno], -1, (0,255,0), 2)
    cv2.circle(resultado, (cx, cy), 4, (0,0,255), -1)
    cv2.putText(resultado, f"Vertices: {vertices}", (cx-40, cy-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,0,0), 1)
    print(f"Figura {i+1}: Area={area:.2f}, Perimetro={perimetro:.2f}, Vertices={vertices}")

cv2.imwrite('output/contornos.png', resultado)

# ------------------------------------------------------------
# 4. Crear GIF animado
# ------------------------------------------------------------
frames = [
    cv2.imread('output/binarizada.png'),
    cv2.imread('output/adaptativa.png'),
    cv2.imread('output/contornos.png')
]
frames = [cv2.cvtColor(f, cv2.COLOR_BGR2RGB) for f in frames]
imageio.mimsave('output/resultados_animados.gif', frames, duration=1.5)
print("✅ GIF generado en output/resultados_animados.gif")
