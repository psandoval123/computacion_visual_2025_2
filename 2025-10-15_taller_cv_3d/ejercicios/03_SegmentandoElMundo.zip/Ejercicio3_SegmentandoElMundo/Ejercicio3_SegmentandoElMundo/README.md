# Ejercicio 3 — Segmentando el Mundo (Binarización y Contornos)

### Objetivo
Implementar segmentación de imágenes con OpenCV para detectar contornos, calcular centroides y clasificar figuras por vértices.

### Pasos realizados
1. Conversión de imagen a escala de grises.
2. Aplicación de umbral global y adaptativo.
3. Detección de contornos.
4. Cálculo de área, perímetro y centroides.
5. Clasificación básica según cantidad de vértices.
6. Generación de animación GIF comparativa.

### Tecnologías
- Python 3.x  
- OpenCV  
- NumPy  
- ImageIO

### Ejecución
```bash
python ejercicio3_segmentacion.py
```

### Evidencia
- output/binarizada.png
- output/adaptativa.png
- output/contornos.png
- output/resultados_animados.gif
